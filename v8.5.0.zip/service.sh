rm /data/thermal/config/*
rm /data/vendor/thermal/*

p=$(getprop vendor.sys.thermal.data.path)
if [[ "$p" != "" ]]; then
  rm $p/config/*
fi

#清除电量缓存，提高流畅度
rm -rf /data/data/com.miui.powerkeeper/cache/*
rm -rf /data/data/com.miui.powerkeeper/code_cache/*
rm -rf /data/user_de/0/com.miui.powerkeeper/cache/*
rm -rf /data/user_de/0/com.miui.powerkeeper/code_cache/*
rm -rf /data/user/0/com.miui.powerkeeper/cache/*
rm -rf /data/user/0/com.miui.powerkeeper/code_cache/*

#禁用binder活页夹日志，节省部分微弱的CPU开销
echo "0" > /sys/module/binder/parameters/debug_mask

