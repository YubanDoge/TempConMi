#!/sbin/sh
SKIPMOUNT=false
